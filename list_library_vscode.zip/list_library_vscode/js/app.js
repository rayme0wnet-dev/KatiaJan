const seedBooks = [
 {id:1,title:'Чистый код',author:'Роберт Мартин',year:2008,cover:'#536d5b'},
 {id:2,title:'Маленький принц',author:'Антуан де Сент-Экзюпери',year:1943,cover:'#b47b58'},
 {id:3,title:'Мастер и Маргарита',author:'Михаил Булгаков',year:1967,cover:'#59677d'},
 {id:4,title:'1984',author:'Джордж Оруэлл',year:1949,cover:'#8b554b'},
 {id:5,title:'Атлант расправил плечи',author:'Айн Рэнд',year:1957,cover:'#7c8060'},
 {id:6,title:'Гордость и предубеждение',author:'Джейн Остин',year:1813,cover:'#9a7180'}
];
let books = JSON.parse(localStorage.getItem('listBooks') || 'null') || seedBooks;
let readers = JSON.parse(localStorage.getItem('listReaders') || 'null') || [
 {id:1,name:'Алина Садыкова',email:'alina@example.com'},
 {id:2,name:'Данияр Нурланов',email:'daniyar@example.com'},
 {id:3,name:'София Иванова',email:'sofia@example.com'}
];
let loans = JSON.parse(localStorage.getItem('listLoans') || 'null') || [];
let nextId = Math.max(0,...books.map(x=>x.id),...readers.map(x=>x.id))+1;
const $ = id => document.getElementById(id);
const save = () => {localStorage.setItem('listBooks',JSON.stringify(books));localStorage.setItem('listReaders',JSON.stringify(readers));localStorage.setItem('listLoans',JSON.stringify(loans));};
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2300)}
function isIssued(id){return loans.some(l=>l.bookId===id)}
function render(){
 save();
 const available=books.filter(b=>!isIssued(b.id)).length;
 $('total-books').textContent=$('stat-books').textContent=books.length;
 $('total-readers').textContent=$('stat-readers').textContent=readers.length;
 $('total-loans').textContent=$('stat-issued').textContent=loans.length;
 $('available-books').textContent=$('stat-available').textContent=available;
 const a=books.length?Math.round(available/books.length*100):0, i=books.length?100-a:0;
 $('available-percent').textContent=a+'%';$('issued-percent').textContent=i+'%';
 $('available-bar').style.width=a+'%';$('issued-bar').style.width=i+'%';
 $('featured-books').innerHTML=books.slice(0,3).map(bookCard).join('');
 renderBooks();renderReaders();renderLoans();
}
function bookCard(b){
 const issued=isIssued(b.id);
 return `<article class="book-card"><div class="cover" style="background:${b.cover||'#607866'}">${esc(b.title)}</div><div class="book-details"><h3>${esc(b.title)}</h3><p>${esc(b.author)}</p><span class="book-year">${esc(b.year)}</span><span class="pill ${issued?'issued':''}">${issued?'Выдана':'Доступна'}</span><div class="card-actions"><button class="link-btn" data-action="edit-book" data-id="${b.id}">Изменить</button><button class="link-btn" data-action="delete-book" data-id="${b.id}">Удалить</button></div></div></article>`;
}
function renderBooks(){
 const q=$('book-search').value.toLowerCase(), filter=$('book-filter').value;
 const list=books.filter(b=>(b.title+' '+b.author).toLowerCase().includes(q)&&(filter==='all'||(filter==='issued'?isIssued(b.id):!isIssued(b.id))));
 $('all-books').innerHTML=list.map(bookCard).join('');$('books-empty').classList.toggle('hidden',list.length>0);
}
function renderReaders(){
 $('reader-list').innerHTML=readers.map(r=>`<article class="reader-card"><div class="reader-avatar">${esc(r.name.charAt(0).toUpperCase())}</div><strong>${esc(r.name)}</strong><p>${esc(r.email||'Электронная почта не указана')}</p><div class="card-actions"><button class="link-btn" data-action="delete-reader" data-id="${r.id}">Удалить читателя</button></div></article>`).join('')||'<div class="empty">Пока нет зарегистрированных читателей.</div>';
}
function renderLoans(){
 $('loan-list').innerHTML=loans.map(l=>{const b=books.find(x=>x.id===l.bookId),r=readers.find(x=>x.id===l.readerId);return `<tr><td>${esc(b?.title||'Книга удалена')}</td><td>${esc(r?.name||'Читатель удалён')}</td><td>${esc(l.date)}</td><td><button class="return-btn" data-action="return" data-id="${l.id}">Вернуть книгу</button></td></tr>`}).join('');
 $('loans-empty').classList.toggle('hidden',loans.length>0);
}
const titles={home:'Добро пожаловать',books:'Каталог книг',readers:'Наши читатели',loans:'Выдача и возврат',stats:'Статистика'};
function go(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));document.querySelectorAll('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('page-title').textContent=titles[page];}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
$('today').textContent=new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',year:'numeric'}).format(new Date());
$('book-search').addEventListener('input',renderBooks);$('book-filter').addEventListener('change',renderBooks);

const modal=$('modal'),fields=$('modal-fields'),form=$('modal-form');let formMode='',editingId=null;
function openModal(title,mode,fieldHtml,id=null){formMode=mode;editingId=id;$('modal-title').textContent=title;fields.innerHTML=fieldHtml;modal.classList.add('open')}
function closeModal(){modal.classList.remove('open');form.reset()}
$('modal-close').onclick=$('cancel-modal').onclick=closeModal;
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
$('add-book-btn').onclick=()=>openModal('Добавить книгу','add-book',`
<div class="field"><label>Название книги</label><input name="title" required maxlength="80" placeholder="Например, Чистый код"></div>
<div class="field"><label>Автор</label><input name="author" required maxlength="60" placeholder="Имя автора"></div>
<div class="field"><label>Год издания</label><input name="year" type="number" min="0" max="2026" required placeholder="2024"></div>`);
$('add-reader-btn').onclick=()=>openModal('Добавить читателя','add-reader',`
<div class="field"><label>Имя и фамилия</label><input name="name" required maxlength="60" placeholder="Имя читателя"></div>
<div class="field"><label>Электронная почта</label><input name="email" type="email" placeholder="reader@example.com"></div>`);
$('issue-book-btn').onclick=()=>{
 const free=books.filter(b=>!isIssued(b.id));
 if(!free.length){toast('Нет доступных книг для выдачи');return}
 if(!readers.length){toast('Сначала добавьте читателя');return}
 openModal('Выдать книгу','issue',`
 <div class="field"><label>Книга</label><select name="bookId" required>${free.map(b=>`<option value="${b.id}">${esc(b.title)} — ${esc(b.author)}</option>`).join('')}</select></div>
 <div class="field"><label>Читатель</label><select name="readerId" required>${readers.map(r=>`<option value="${r.id}">${esc(r.name)}</option>`).join('')}</select></div>`);
};
form.addEventListener('submit',e=>{
 e.preventDefault();const data=Object.fromEntries(new FormData(form).entries());
 if(formMode==='add-book'){books.push({id:nextId++,title:data.title.trim(),author:data.author.trim(),year:Number(data.year),cover:['#536d5b','#b47b58','#59677d','#8b554b','#7c8060','#9a7180'][books.length%6]});toast('Книга добавлена в каталог')}
 if(formMode==='edit-book'){const b=books.find(x=>x.id===editingId);Object.assign(b,{title:data.title.trim(),author:data.author.trim(),year:Number(data.year)});toast('Изменения сохранены')}
 if(formMode==='add-reader'){readers.push({id:nextId++,name:data.name.trim(),email:data.email.trim()});toast('Читатель добавлен')}
 if(formMode==='issue'){loans.push({id:nextId++,bookId:Number(data.bookId),readerId:Number(data.readerId),date:new Intl.DateTimeFormat('ru-RU').format(new Date())});toast('Книга выдана читателю')}
 closeModal();render();
});
document.addEventListener('click',e=>{
 const btn=e.target.closest('[data-action]');if(!btn)return;
 const id=Number(btn.dataset.id),action=btn.dataset.action;
 if(action==='delete-book'){if(isIssued(id)){toast('Сначала верните выданную книгу');return}if(confirm('Удалить эту книгу из каталога?')){books=books.filter(b=>b.id!==id);render();toast('Книга удалена')}}
 if(action==='edit-book'){const b=books.find(x=>x.id===id);openModal('Изменить книгу','edit-book',`
 <div class="field"><label>Название книги</label><input name="title" required value="${esc(b.title)}"></div>
 <div class="field"><label>Автор</label><input name="author" required value="${esc(b.author)}"></div>
 <div class="field"><label>Год издания</label><input name="year" type="number" min="0" max="2026" required value="${b.year}"></div>`,id)}
 if(action==='delete-reader'){if(loans.some(l=>l.readerId===id)){toast('Нельзя удалить читателя с невозвращённой книгой');return}if(confirm('Удалить читателя?')){readers=readers.filter(r=>r.id!==id);render();toast('Читатель удалён')}}
 if(action==='return'){loans=loans.filter(l=>l.id!==id);render();toast('Книга успешно возвращена')}
});
render();
